package model;

import java.util.ArrayList;

public class Fileoperations {
    public void readFile(ArrayList InvoiceLines) {

    }

    public void writeFile(ArrayList InvoiceLines) {

    }
}
